// Author: Adam Vesely (xvesela00)


// Build script for Tauri application
fn main() {
  tauri_build::build()
}
